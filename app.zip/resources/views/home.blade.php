@extends('layouts.app')
@section('title', 'Inicio')
hola
endsection