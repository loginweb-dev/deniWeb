<footer class="page-footer text-center text-md-left stylish-color-dark pt-0">

    <div style="background-color: #4285f4;">

      <div class="container">

        <!-- Grid row -->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">

            <h6 class="mb-0 white-text">¡Conéctate con nosotros en las redes sociales!</h6>

          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right">

            <!-- Facebook -->
            <a class="fb-ic ml-0 px-2"><i class="fab fa-facebook-f white-text"> </i></a>

            <!-- Twitter -->
            <a class="tw-ic px-2"><i class="fab fa-twitter white-text"> </i></a>

            <!-- Google + -->
            <a class="gplus-ic px-2"><i class="fab fa-google-plus-g white-text"> </i></a>

            <!-- Linkedin -->
            <a class="li-ic px-2"><i class="fab fa-linkedin-in white-text"> </i></a>

            <!-- Instagram -->
            <a class="ins-ic px-2"><i class="fab fa-instagram white-text"> </i></a>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </div>

    </div>

    <!-- Footer Links -->
    
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright py-3 text-center">

      <div class="container-fluid">

        © 2019 Copyright: <a href="" target="_blank"> LoginWeb.net</a>

      </div>

    </div>
    <!-- Copyright -->

  </footer><?php /**PATH /home2/loginwe3/deni/resources/views/layouts/footer.blade.php ENDPATH**/ ?>