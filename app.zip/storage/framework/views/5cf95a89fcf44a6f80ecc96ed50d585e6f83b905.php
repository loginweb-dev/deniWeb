<div class="card">
    <div class="card-body">
        <?php if($errors->has('commentable_type')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($errors->get('commentable_type')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->has('commentable_id')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($errors->get('commentable_id')); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(url('comments')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo view('honeypot::honeypotFormFields'); ?>
            <input type="hidden" name="commentable_type" value="\<?php echo e(get_class($model)); ?>" />
            <input type="hidden" name="commentable_id" value="<?php echo e($model->id); ?>" />

            
            <?php if(isset($guest_commenting) and $guest_commenting == true): ?>
                <div class="form-group">
                    <label for="message">Enter your name here:</label>
                    <input type="text" class="form-control <?php if($errors->has('guest_name')): ?> is-invalid <?php endif; ?>" name="guest_name" />
                    <?php if ($errors->has('guest_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guest_name'); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label for="message">Enter your email here:</label>
                    <input type="email" class="form-control <?php if($errors->has('guest_email')): ?> is-invalid <?php endif; ?>" name="guest_email" />
                    <?php if ($errors->has('guest_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guest_email'); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            <?php endif; ?>

            <div class="form-group">
                <label for="message">Enter your message here:</label>
                <textarea class="form-control <?php if($errors->has('message')): ?> is-invalid <?php endif; ?>" name="message" rows="3"></textarea>
                <div class="invalid-feedback">
                    Your message is required.
                </div>
                <small class="form-text text-muted"><a target="_blank" href="https://help.github.com/articles/basic-writing-and-formatting-syntax">Markdown</a> cheatsheet.</small>
            </div>
            <button type="submit" class="btn btn-sm btn-outline-success text-uppercase">Submit</button>
        </form>
    </div>
</div>
<br /><?php /**PATH /Applications/MAMP/htdocs/deni/resources/views/vendor/comments/_form.blade.php ENDPATH**/ ?>