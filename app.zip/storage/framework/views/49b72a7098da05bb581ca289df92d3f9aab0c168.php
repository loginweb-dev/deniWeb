<div class="container mt-5 pt-3">
  
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-dark primary-color mt-5">
  
        <!-- Navbar brand -->
        <a class="font-weight-bold white-text mr-4" href="#">Negocios</a>
  
        <!-- Collapse button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1"
          aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"><span
            class="navbar-toggler-icon"></span></button>
  
        <!-- Collapsible content -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent1">
  
          <!-- Links -->
          
          <!-- Links -->
  
          <!-- Search form -->
          <form class="search-form" role="search">
  
            <div class="form-group md-form my-0 waves-light">
  
              <input type="text" class="form-control" placeholder="Buscar">
  
            </div>
  
          </form>
  
        </div>
        <!-- Collapsible content -->
  
      </nav>
      <!-- Navbar -->
  
    </div><?php /**PATH C:\laragon\www\deni\resources\views/layouts/megamenu.blade.php ENDPATH**/ ?>