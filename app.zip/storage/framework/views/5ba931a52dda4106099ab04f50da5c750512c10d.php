<?php echo e($slot); ?>

<?php /**PATH /home2/loginwe3/deni/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>