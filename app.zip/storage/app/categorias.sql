-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 25-10-2019 a las 08:44:58
-- Versión del servidor: 5.6.41-84.1
-- Versión de PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `loginwe3_deni`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`, `image`, `icon`) VALUES
(1, 'Turismo Rural', '2019-10-19 23:36:35', '2019-10-24 01:25:26', NULL, NULL, 'fas fa-globe-americas dark-grey-text mr-3'),
(2, 'Turismo Urbano', '2019-10-19 23:36:56', '2019-10-25 02:18:43', NULL, NULL, 'fas fa-car-side dark-grey-text mr-3'),
(3, 'Lugares Publicos', '2019-10-19 23:37:11', '2019-10-25 02:19:48', NULL, NULL, 'fas fa-archway dark-grey-text mr-3'),
(4, 'Farmacias', '2019-10-19 23:37:20', '2019-10-25 02:20:30', NULL, NULL, 'fas fa-briefcase-medical dark-grey-text mr-3'),
(5, 'Salud', '2019-10-19 23:37:29', '2019-10-25 02:22:13', NULL, NULL, 'fas fa-clinic-medical dark-grey-text mr-3'),
(6, 'Educacion', '2019-10-19 23:37:38', '2019-10-25 02:23:14', NULL, NULL, 'fas fa-city dark-grey-text mr-3'),
(7, 'Restaurantes', '2019-10-19 23:38:08', '2019-10-25 02:24:40', NULL, NULL, 'fas fa-hamburger dark-grey-text mr-3'),
(8, 'Hoteles', '2019-10-19 23:38:23', '2019-10-19 23:38:23', NULL, NULL, NULL),
(9, 'Transporte', '2019-10-19 23:38:37', '2019-10-19 23:38:37', NULL, NULL, NULL),
(10, 'Religion', '2019-10-19 23:38:49', '2019-10-19 23:38:49', NULL, NULL, NULL),
(11, 'Casas Comerciales', '2019-10-19 23:39:00', '2019-10-19 23:39:15', NULL, NULL, NULL),
(12, 'Super & shoping', '2019-10-19 23:39:42', '2019-10-19 23:39:42', NULL, NULL, NULL),
(13, 'Boutique & Zapatos', '2019-10-19 23:40:01', '2019-10-24 01:22:38', NULL, NULL, 'fas fa-shoe-prints dark-grey-text mr-3'),
(14, 'Belleza & Peliqueria', '2019-10-19 23:40:33', '2019-10-24 01:21:25', NULL, NULL, 'fas fa-cut dark-grey-text mr-3'),
(15, 'Tecnologias', '2019-10-19 23:43:20', '2019-10-24 01:15:58', NULL, NULL, 'fas fa-tv dark-grey-text mr-3');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
